
<!DOCTYPE html>
<html>
<head>
<link href="https://fonts.googleapis.com/css?family=Roboto:400,500,700" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="users.css">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<title>BLOGS</title>
<style type="text/css">
	.x{
		overflow-x: hidden;
		overflow-y: scroll;
		height: 300px;
		width: 500px;
		background-image: url("https://i.pinimg.com/originals/98/da/8f/98da8f9306de27424460d16e53938b72.jpg");
	}
</style>
</head>

<body>
	<div class="log">
		<form action="logout.php">
			<button class="w3-button w3-red w3-rounded">LOGOUT</button>
		</form>
	</div>
	<div>
		<div style="font-size: 20px; text-align: center; font-family: cursive; text-transform: uppercase;">
			<?php
				session_start();
				$name=$_SESSION['var'];
				echo "<div >Welcome ".$name."</div>";
			?>
		</div>
		<br>
		<div class="x" style="font-size: 25px; color: #e53e3e;; text-align: left; font-family: Roboto; margin-left: 31%; border: solid black 2px; padding: 10px;">
			<?php
				$file=fopen("Myfile.txt","r")or die("Unable to open file");
				echo "<div>".fread($file,filesize("Myfile.txt"))."</div>";
				fclose($file);
			?>
		</div>
	</div>
<div id="blog">
<form action="userblog.php">
	<button class="w3-button w3-green" >VIEW BLOG</button>
</form>
</div>
</body>
</html>

