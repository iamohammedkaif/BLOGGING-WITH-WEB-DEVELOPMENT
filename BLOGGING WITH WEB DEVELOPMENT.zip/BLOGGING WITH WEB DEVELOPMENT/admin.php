<!DOCTYPE html>
<html>
<head>
<link href="https://fonts.googleapis.com/css?family=Roboto:400,500,700" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="adblog.css">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<title>Welcome to blogs</title>
<style> 
input[type=text] {
  width: 40%;
  padding: 10px 10px;
  margin: 8px 0;
  box-sizing: border-box;
  border: 3px solid #ccc;
  -webkit-transition: 0.5s;
  transition: 0.5s;
  outline: none;
}

input[type=text]:focus {
  border: 3px solid #555;
}
.x{
		overflow-x: hidden;
		overflow-y: scroll;
		height: 300px;
		width: 800px;
		background-image: url("https://i.pinimg.com/originals/98/da/8f/98da8f9306de27424460d16e53938b72.jpg");

	}
</style>
</head>
<body>
	<form action="logout.php">
			<button class="w3-bar-item w3-button w3-red" id="logout">LOGOUT</button>
	</form>
	<img class="com" src="logo.png">
	<div class="border"></div>
	<div class="x"  style="font-size: 20px; text-align: left; font-family: cursive; border:solid 5px; margin-top: 10px;border-style: double;  padding-left: 10px; margin-left: 20%; ">
		<?php 
			$file=fopen("Myfile.txt", "r")or die("Unable to open to file");
			echo fread($file, filesize("Myfile.txt"));
			fclose($file);
		?>
	</div>
	 <div id="align">
	 	<form action="insertcon.php" method="POST">
			<input id="get" class="textcontent" type="text" name="textarea">
			<button id="post" class="w3-button w3-green" name="submit" type="submit">SEND</button>
		</form>
		<form action="postblog.php">
			<button class="w3-bar-item w3-button w3-blue" id="write">WRITE BLOG</button>
	</form>
	</div>

</body>
</html>