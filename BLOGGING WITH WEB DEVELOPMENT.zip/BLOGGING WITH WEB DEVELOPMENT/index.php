<!DOCTYPE html>
<html>
<head>
	<link href="https://fonts.googleapis.com/css?family=Roboto:400,500,700" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="style.css">
	<script src="js/jquery-3.3.1.min.js"></script>
	<script src="js/index.js"></script>
	<title>Welcome to blogs</title>
</head>
<body>
	<div class="ba"></div>
	<img class="com" src="logo.png">
	<div class="border"></div>
	<table style="width: 100%" >
		<tr>
			<td style="float:left;">
				<p class="shadow-pop-br">
  					<b>Welcome to our world! Here u can get to know everything about us and our personal life and some of our latent writing skills. Just log in to read blogs n topics ranging from climate change to sports, from entertainment to technology.
					We promise you'll not be disappointed.
  					</b>
  				</p>
			</td>
			<td style="float:right;">
  				<div class="card" >
					<div class="head">
						<div></div>
						<a id="signup" href="#signup">Sign up</a>
						<a id="login" class="selected" href="#login">Login</a>
					<div></div>
					</div>
					<div class="tabs">
						<form action="insertlogin.php" method="post">
							<div class="inputs">
								<div class="input">
								<input name="username" placeholder="Username" type="text">
								<img src="img/user.svg">
								</div>
							<div class="input">
								<input name="password" placeholder="Password" type="password">
								<img src="img/pass.svg">
							</div>
							</div>
							<button class="submit" name="submit" type="submit">Login</button> 
						</form>
						<form action="insertsignup.php" method="post">
							<div class="inputs">
								<div class="input">
									<input name="name" placeholder="Name" type="text">
									<img src="img/user.svg">
								</div>
								<div class="input">
									<input name="email" placeholder="Email" type="email">
									<img src="img/mail.svg">
								</div>
								<div class="input">
									<input name="username" placeholder="Username" type="text">
									<img src="img/user.svg">
								</div>
								<div class="input">
									<input name="password" placeholder="Password" type="password">
									<img src="img/pass.svg">
								</div>
							</div>
								<button class="ssubmit" name="ssubmit" type="ssubmit">Signup</button> 
						</form>
					</div>
  			</td>
  		</tr>
  	</table>
</body>
</html>
