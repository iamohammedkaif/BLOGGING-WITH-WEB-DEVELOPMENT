$(window).on("hashchange", function(){
	if(location.hash.slice(1)=="login"){
		$(".card").removeClass("extend");
		$("#signup").removeClass("selected");
		$("#login").addClass("selected");
	} else {
		$(".card").addClass("extend");
		$("#signup").addClass("selected");
		$("#login").removeClass("selected");
	}
});
$(window).trigger("hashchange");

