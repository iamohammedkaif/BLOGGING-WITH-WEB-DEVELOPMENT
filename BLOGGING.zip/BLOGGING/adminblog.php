<?php 
	session_start();
	$name=$_SESSION['var'];
	$my_file=$name.'.txt';
	$handle=fopen($my_file, 'a')or die('cannot open my file'.$my_file);
	$data=$_POST["blog"];
	fwrite($handle, $data);
	fwrite($handle, "<br/>......................<br/>");
	echo "<script>alert('POSTED...!!');window.location.href='admin.php';</script>";
 ?>