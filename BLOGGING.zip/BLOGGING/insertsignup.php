<?php
$connection = mysqli_connect("localhost", "root", "","login"); // Establishing Connection with Server
// $db = mysqli_select_db("colleges", $connection); // Selecting Database from Server
if(isset($_POST['ssubmit']))
{ 
	// Fetching variables of the form which travels in URL
	$name=$_POST['name'];
	$email=$_POST['email'];
	$username = $_POST['username'];
	$password = $_POST['password'];
	if($username !=''||$password !='')
	{
		$query = mysqli_query($connection,"insert into logindetails(name,email,username,password) values ('$name','$email','
			$username', '$password')");
		echo "<script>alert('Signup successful...!!');window.location.href='index.php';</script>";
	}
	else
	{
		echo "<script>alert('Insertion Failed.Some Fields are Blank....!!');window.location.href='index.php';</script>";	
	}
}
mysqli_close($connection); // Closing Connection with Server
?>