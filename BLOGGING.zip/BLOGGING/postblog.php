<!DOCTYPE html>
<html>
<head>

	<title>WRITE BLOG</title>
	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
	<link rel="stylesheet" type="text/css" href="users.css">
	<style type="text/css">
		input[type=text] {
  width: 40%;
  padding: 10px 10px;
  margin: 8px 0;
  box-sizing: border-box;
  border: 3px solid #ccc;
  -webkit-transition: 0.5s;
  transition: 0.5s;
  outline: none;
}

input[type=text]:focus {
  border: 3px solid #555;
}
	</style>
</head>
<body>
	<h3>POST ANYTHING YOU WHAT</h3>
	<form action="adminblog.php" method="POST">
		<input type="text" name="blog">
		<button class="w3-bar-item w3-button w3-purple" name="submit" type="submit">POST</button>
	</form>

</body>
</html>