<?php
session_start();
$connection = mysqli_connect("localhost", "root", "","login"); // Establishing Connection with Server
if(isset($_POST['submit'])) 
{
      $myusername=$_POST['username'];
      $mypassword=$_POST['password']; 
      $sql = "SELECT * FROM logindetails WHERE username ='$myusername' and password = '$mypassword'";
      $result = mysqli_query($connection,$sql);
      if($row=mysqli_fetch_array($result))
      {
          $_SESSION['var']=$row['name'];
      		if(preg_match("/^admin*/",$myusername))
            echo "<script>alert('Welcome Admin...!!');window.location.href='admin.php';</script>";
      	 	else
            echo "<script>alert('Login successful..!!');window.location.href='user.php';</script>";
       }
      else 
        echo "<script>alert('Your entered username or password is incorrect...!!');window.location.href='index.php';</script>";
     }

mysqli_close($connection); // Closing Connection with Server
?>