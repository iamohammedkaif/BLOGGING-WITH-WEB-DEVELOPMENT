<!DOCTYPE html>
<html>
<head>
  <?php
    $neeraj=fopen("Neeraj.txt","r")or die("Unable to open file");
    $data1=fread($neeraj,filesize("Neeraj.txt"));
    fclose($neeraj);

    $nishant=fopen("Nishant.txt","r")or die("Unable to open file");
    $data2=fread($nishant,filesize("Nishant.txt"));
    fclose($nishant);

    $kaif=fopen("Kaif.txt","r")or die("Unable to open file");
    $data3=fread($kaif,filesize("Kaif.txt"));
    fclose($kaif);
    
    $nikhilesh=fopen("Nikhilesh.txt","r")or die("Unable to open file");
    $data4=fread($nikhilesh,filesize("Nikhilesh.txt"));
    fclose($nikhilesh);
  ?>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
* {box-sizing: border-box}

body, html {
  height: 100%;
  margin: 0;
  font-family: Arial;
}
.tablink {
  background-color: #555;
  color: white;
  float: left;
  border: inset;
  outline: none;
  cursor: pointer;
  padding: 14px 16px;
  font-size: 17px;
  width: 25%;
}

.tablink:hover {
  background-color: #777;
}
.tabcontent {
  color: white;
  display: none;
  padding: 100px 20px;
  height: 100%;
}

#Neeraj {background-color:orange;}
#Kaif {background-color:olive;}
#Nishant {background-color:brown;}
#Nikhilesh {background-color:grey;}
</style>
</head>
<body>
<button class="tablink" onclick="openPage('Neeraj', this, 'orange')" id="defaultOpen">Neeraj</button>
<button class="tablink" onclick="openPage('Kaif', this, 'olive')">Kaif</button>
<button class="tablink" onclick="openPage('Nishant', this, 'brown')">Nishant</button>
<button class="tablink" onclick="openPage('Nikhilesh', this, 'grey')">Nikhilesh</button>

<div id="Neeraj" class="tabcontent">
  <h2>By Neeraj</h2>
  <p><?php echo $data1; ?></p>
</div>

<div style="font-size:10pt;" id="Nishant" class="tabcontent">
  <h2>By Nishant</h2>
  <p ><?php echo $data2; ?></p>
</div>

<div id="Kaif" class="tabcontent">
  <h2>By Kaif</h2>
  <p><?php echo $data3; ?></p>
</div>

<div id="Nikhilesh" class="tabcontent">
  <h2>By Nikhilesh</h2>
  <p><?php echo $data4; ?></p>
</div>

<script>
function openPage(pageName,elmnt,color) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablink");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].style.backgroundColor = "";
  }
  document.getElementById(pageName).style.display = "block";
  elmnt.style.backgroundColor = color;
}

document.getElementById("defaultOpen").click();
</script>
   
</body>
</html> 