<?php
	session_start();
	$my_file = 'Myfile.txt';
	$handle = fopen($my_file, 'a') or die('Cannot open file:  '.$my_file);
	$data = $_POST["textarea"];
	$name= $_SESSION['var'];
	fwrite($handle, $name);
	fwrite($handle, ":");
	fwrite($handle, $data);
	fwrite($handle,"<br/>");
	echo '<script type="text/javascript">';
	echo 'alert("POSTED!!!!!!")';
	echo '</script>';
	header("location:admin.php");
?>


